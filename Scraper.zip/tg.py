# Telegram module: all !tg commands in one file. Fresh check on every
# select/check, duplicate protection via telegram_downloader.db, optional
# background monitoring, DM-based login. If Telegram is not configured,
# commands reply with a notice instead of crashing.

import asyncio
import logging
import os
import re
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

import discord
from discord.ext import commands, tasks
from dotenv import load_dotenv

from bot import (FOOTER, OWNER_ID, PREFIX, ConfirmView, Paginator, Theme,
                 admin_only, is_admin, owner_only, paginate)

try:
    from telethon import TelegramClient, errors, utils
    from telethon.errors import SessionPasswordNeededError
    from telethon.tl.types import MessageMediaWebPage
    TELETHON = True
except ImportError:
    TELETHON = False

log = logging.getLogger("tg")
load_dotenv()

TG_API_ID = os.getenv("TELEGRAM_API_ID", "").strip()
TG_API_HASH = os.getenv("TELEGRAM_API_HASH", "").strip()
TG_SESSION = os.getenv("TELEGRAM_SESSION", "telegram_downloader").strip()
try:
    DEFAULT_POSTS = max(1, int(os.getenv("TELEGRAM_POSTS", "10")))
except ValueError:
    DEFAULT_POSTS = 10
DEFAULT_FOLDER = os.getenv("TELEGRAM_DOWNLOAD_DIR", "telegram_downloads")
MAX_NAME = 120


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _hsize(n) -> str:
    n = float(n or 0)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{int(n)} B" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024


class TGDB:
    def __init__(self, path="telegram_downloader.db"):
        self.con = sqlite3.connect(path)
        self.con.row_factory = sqlite3.Row
        with self.con:
            self.con.execute("""CREATE TABLE IF NOT EXISTS channels(
                channel_id INTEGER PRIMARY KEY,
                username TEXT UNIQUE NOT NULL,
                title TEXT DEFAULT '',
                enabled INTEGER DEFAULT 1,
                last_message_id INTEGER DEFAULT 0,
                last_check TEXT DEFAULT '',
                added_at TEXT DEFAULT '')""")
            self.con.execute("""CREATE TABLE IF NOT EXISTS downloads(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                channel_id INTEGER NOT NULL,
                message_id INTEGER NOT NULL,
                file_id TEXT DEFAULT '',
                filename TEXT DEFAULT '',
                file_path TEXT DEFAULT '',
                file_size INTEGER DEFAULT 0,
                status TEXT DEFAULT 'done',
                error TEXT DEFAULT '',
                downloaded_at TEXT DEFAULT '',
                UNIQUE(channel_id, message_id, file_id))""")
            self.con.execute("""CREATE INDEX IF NOT EXISTS idx_dl_channel
                ON downloads(channel_id)""")
            self.con.execute("""CREATE TABLE IF NOT EXISTS settings(
                key TEXT PRIMARY KEY, value TEXT)""")

    def set_setting(self, key, value):
        with self.con:
            self.con.execute(
                "INSERT OR REPLACE INTO settings(key,value) VALUES (?,?)",
                (key, str(value)))

    def get_setting(self, key, default=None):
        row = self.con.execute("SELECT value FROM settings WHERE key=?",
                               (key,)).fetchone()
        return row["value"] if row else default

    def add_channel(self, channel_id, username, title):
        with self.con:
            self.con.execute(
                "INSERT OR REPLACE INTO channels(channel_id, username, title,"
                " enabled, last_message_id, last_check, added_at) "
                "VALUES (?,?,?,1,0,'',?)",
                (channel_id, username, title, _now()))

    def remove_channel(self, username) -> bool:
        with self.con:
            cur = self.con.execute("DELETE FROM channels WHERE username=?",
                                   (username,))
        return cur.rowcount > 0

    def get_channel(self, username):
        return self.con.execute("SELECT * FROM channels WHERE username=?",
                                (username,)).fetchone()

    def list_channels(self):
        return self.con.execute(
            "SELECT * FROM channels ORDER BY username").fetchall()

    def update_check(self, channel_id, last_message_id):
        with self.con:
            self.con.execute(
                "UPDATE channels SET last_message_id=?, last_check=? "
                "WHERE channel_id=?", (last_message_id, _now(), channel_id))

    def is_downloaded(self, channel_id, message_id, file_id) -> bool:
        row = self.con.execute(
            "SELECT 1 FROM downloads WHERE channel_id=? AND message_id=? "
            "AND file_id=? AND status='done'",
            (channel_id, message_id, file_id)).fetchone()
        return row is not None

    def record_download(self, channel_id, message_id, file_id, filename,
                        file_path, size, status, error):
        with self.con:
            self.con.execute(
                "INSERT OR REPLACE INTO downloads(channel_id, message_id, "
                "file_id, filename, file_path, file_size, status, error, "
                "downloaded_at) VALUES (?,?,?,?,?,?,?,?,?)",
                (channel_id, message_id, file_id, filename, file_path, size,
                 status, error, _now()))

    def recent(self, limit=10):
        return self.con.execute(
            "SELECT d.*, c.username FROM downloads d "
            "LEFT JOIN channels c ON c.channel_id = d.channel_id "
            "WHERE d.status='done' ORDER BY d.id DESC LIMIT ?",
            (limit,)).fetchall()

    def stats(self):
        total = self.con.execute(
            "SELECT COUNT(*) AS c, COALESCE(SUM(file_size),0) AS s, "
            "MAX(downloaded_at) AS last FROM downloads WHERE status='done'"
        ).fetchone()
        per = self.con.execute(
            "SELECT c.username, COUNT(*) AS c, COALESCE(SUM(d.file_size),0) AS s "
            "FROM downloads d JOIN channels c ON c.channel_id=d.channel_id "
            "WHERE d.status='done' GROUP BY c.username ORDER BY c DESC"
        ).fetchall()
        failed = self.con.execute(
            "SELECT COUNT(*) AS c FROM downloads WHERE status='failed'"
        ).fetchone()["c"]
        return total, per, failed


class ChannelSelect(discord.ui.Select):
    def __init__(self, cog):
        options = [discord.SelectOption(label=f"@{r['username']}",
                                        value=r["username"],
                                        description=(r["title"] or "")[:100])
                   for r in cog.db.list_channels()[:25]]
        super().__init__(placeholder="Select a channel to check now",
                         options=options)
        self.cog = cog

    async def callback(self, interaction):
        row = self.cog.db.get_channel(self.values[0])
        if row is None:
            return await interaction.response.send_message(
                "That channel is no longer configured.", ephemeral=True)
        await interaction.response.defer(thinking=True)
        try:
            result = await self.cog._check_channel(row)
        except Exception as ex:
            return await interaction.followup.send(
                embed=self.cog._error_embed(row["username"], ex))
        await interaction.followup.send(
            embed=self.cog._result_embed(row["username"], result))


class ChannelSelectView(discord.ui.View):
    def __init__(self, cog):
        super().__init__(timeout=180)
        self.cog = cog
        self.add_item(ChannelSelect(cog))

    async def interaction_check(self, interaction):
        if interaction.user.id != OWNER_ID and not is_admin(interaction.user.id):
            await interaction.response.send_message(
                "You do not have permission to use this control.",
                ephemeral=True)
            return False
        return True


class TgMenuView(discord.ui.View):
    def __init__(self, cog, user_id):
        super().__init__(timeout=180)
        self.cog = cog
        self.user_id = user_id

    async def interaction_check(self, interaction):
        if interaction.user.id != self.user_id:
            await interaction.response.send_message(
                "This menu belongs to another user.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="Channels", style=discord.ButtonStyle.primary)
    async def channels(self, interaction, button):
        e = self.cog._list_embed()
        if e is None:
            e = Theme.embed(description="No Telegram channels are configured.",
                            color=Theme.MIDNIGHT)
        await interaction.response.send_message(embed=e)

    @discord.ui.button(label="Status", style=discord.ButtonStyle.secondary)
    async def statusbtn(self, interaction, button):
        await interaction.response.defer(thinking=True)
        await interaction.followup.send(embed=await self.cog._status_embed())

    @discord.ui.button(label="Recent", style=discord.ButtonStyle.secondary)
    async def recentbtn(self, interaction, button):
        rows = self.cog.db.recent(5)
        e = self.cog._recent_pages(rows)
        e = e[0] if e else Theme.embed(description="No files have been "
                                                   "downloaded yet.",
                                       color=Theme.MIDNIGHT)
        await interaction.response.send_message(embed=e)


class TelegramCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.db = TGDB()
        self.client = None
        if not self.db.get_setting("download_dir"):
            self.db.set_setting("download_dir", DEFAULT_FOLDER)
        if not self.db.get_setting("posts"):
            self.db.set_setting("posts", str(DEFAULT_POSTS))

    async def cog_load(self):
        if self._ready()[0] \
                and self.db.get_setting("auto_enabled", "0") == "1" \
                and self.db.get_setting("enabled", "0") == "1":
            self.start_auto()

    async def cog_unload(self):
        if self.auto_loop.is_running():
            self.auto_loop.stop()
        if self.client and TELETHON and self.client.is_connected():
            try:
                asyncio.get_running_loop().create_task(
                    self.client.disconnect())
            except Exception:
                pass

    # ---- config helpers ----

    def _ready(self):
        if not TELETHON:
            return False, ("the telethon library is not installed "
                           "(run: pip install telethon)")
        if not TG_API_ID or not TG_API_HASH:
            return False, ("TELEGRAM_API_ID and TELEGRAM_API_HASH are "
                           "missing in the .env file")
        return True, ""

    async def _require_config(self, ctx):
        ok, reason = self._ready()
        if ok:
            return True
        await ctx.reply("Telegram is not available: " + reason + ". Paste "
                        "commands continue to work normally.",
                        mention_author=False)
        return False

    # ---- small helpers ----

    @staticmethod
    def _clean(name):
        if not name:
            return None
        n = name.strip().lstrip("@").lower()
        if not re.fullmatch(r"[a-z0-9_]{4,32}", n):
            return None
        return n

    def _selected(self):
        return self.db.get_setting("selected_channel")

    def _posts(self) -> int:
        try:
            return max(1, int(self.db.get_setting("posts",
                                                  str(DEFAULT_POSTS))))
        except ValueError:
            return DEFAULT_POSTS

    def _folder(self) -> Path:
        return Path(self.db.get_setting("download_dir", DEFAULT_FOLDER))

    def _auto_interval(self) -> int:
        try:
            return max(1, int(self.db.get_setting("auto_interval", "15")))
        except ValueError:
            return 15

    @staticmethod
    def _file_id(msg):
        try:
            if getattr(msg, "document", None) is not None:
                return f"doc{msg.document.id}"
            if getattr(msg, "photo", None) is not None:
                pid = getattr(msg.photo, "id", None)
                if pid:
                    return f"photo{pid}"
        except Exception:
            pass
        return "media"

    @staticmethod
    def _safe_name(name):
        name = os.path.basename((name or "").strip())
        name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name)
        name = name.strip(". ")
        if not name:
            name = "file"
        return name[:MAX_NAME]

    def _file_name(self, msg):
        name = None
        ext = ""
        try:
            if msg.file:
                if msg.file.name:
                    name = msg.file.name
                if msg.file.ext:
                    ext = msg.file.ext
        except Exception:
            pass
        if not name:
            if msg.photo:
                name = f"photo_{msg.id}{ext or '.jpg'}"
            else:
                name = f"file_{msg.id}{ext}"
        return self._safe_name(name)

    def _friendly(self, ex) -> str:
        if isinstance(ex, errors.ChannelPrivateError):
            return "Unable to access the channel."
        if isinstance(ex, errors.UsernameNotOccupiedError):
            return "That Telegram username does not exist."
        if isinstance(ex, errors.FloodWaitError):
            return (f"Telegram rate limit reached. Try again in "
                    f"{ex.seconds} seconds.")
        if isinstance(ex, RuntimeError):
            return str(ex)
        return f"An unexpected error occurred: {str(ex)[:200]}"

    # ---- telegram connection ----

    async def _get_client(self):
        if self.client is not None and self.client.is_connected():
            if await self.client.is_user_authorized():
                return self.client
        if not TG_API_ID or not TG_API_HASH:
            raise RuntimeError("Telegram is not configured.")
        try:
            api_id = int(TG_API_ID)
        except ValueError:
            raise RuntimeError("TELEGRAM_API_ID in the .env file is not a "
                               "number.")
        if self.client is None:
            self.client = TelegramClient(TG_SESSION, api_id, TG_API_HASH)
        await self.client.connect()
        if not await self.client.is_user_authorized():
            raise RuntimeError("The Telegram session is not authorized. "
                               f"Use {PREFIX}tg login in DMs first.")
        return self.client

    async def _resolve_entity(self, client, username):
        try:
            return await client.get_entity(username)
        except errors.UsernameNotOccupiedError:
            raise RuntimeError("That Telegram username does not exist.")
        except ValueError:
            raise RuntimeError("That Telegram username does not exist.")
        except (errors.ChannelPrivateError, errors.ChannelInvalidError,
                errors.ChannelNotFoundError):
            raise RuntimeError("Unable to access the channel.")
        except errors.FloodWaitError as e:
            raise RuntimeError(f"Telegram rate limit reached. Try again in "
                                f"{e.seconds} seconds.")

    # ---- download core ----

    async def _download_media(self, msg):
        folder = self._folder()
        folder.mkdir(parents=True, exist_ok=True)
        base = self._file_name(msg)
        path = folder / base
        stem, ext = os.path.splitext(base)
        counter = 1
        while path.exists():
            path = folder / f"{stem} ({counter}){ext}"
            counter += 1
        out = await self.client.download_media(msg, file=str(path))
        if not out:
            return None
        actual = Path(out)
        size = actual.stat().st_size if actual.exists() else 0
        return {"filename": actual.name, "path": str(actual), "size": size}

    async def _check_channel(self, row):
        client = await self._get_client()
        entity = await self._resolve_entity(client, row["username"])
        posts = self._posts()
        last_id = row["last_message_id"] or 0
        kwargs = {"limit": posts}
        if last_id > 0:
            kwargs["min_id"] = last_id
        newest = last_id
        found, skipped, failed = [], 0, 0
        async for msg in client.iter_messages(entity, **kwargs):
            if msg.id > newest:
                newest = msg.id
            if msg.media is None or isinstance(msg.media, MessageMediaWebPage):
                continue
            file_id = self._file_id(msg)
            if self.db.is_downloaded(row["channel_id"], msg.id, file_id):
                skipped += 1
                continue
            try:
                info = await self._download_media(msg)
                if info is None:
                    skipped += 1
                    continue
                self.db.record_download(row["channel_id"], msg.id, file_id,
                                        info["filename"], info["path"],
                                        info["size"], "done", "")
                found.append(info)
                log.info("Downloaded %s from @%s", info["filename"],
                         row["username"])
            except Exception as ex:
                failed += 1
                log.error("Download failed in @%s msg %s: %s",
                          row["username"], msg.id, ex)
                self.db.record_download(row["channel_id"], msg.id, file_id,
                                        self._file_name(msg), "", 0,
                                        "failed", str(ex)[:300])
        self.db.update_check(row["channel_id"], newest)
        return {"found": found, "skipped": skipped, "failed": failed}

    # ---- reporting ----

    def _result_embed(self, username, result):
        found = result["found"]
        e = Theme.embed(title="Telegram Channel Checked", color=Theme.GREEN)
        e.add_field(name="Channel", value=f"@{username}", inline=True)
        e.add_field(name="New attachments found", value=str(len(found)),
                    inline=True)
        if found:
            lines = []
            total = 0
            for i, f in enumerate(found[:15], 1):
                lines.append(f"{i}. {f['filename']} ({_hsize(f['size'])})")
                total += f["size"]
            desc = "\n".join(lines)
            if len(found) > 15:
                desc += f"\n...and {len(found) - 15} more"
            e.description = desc
            e.set_footer(text=f"Total: {_hsize(total)} | all files were "
                              f"downloaded to the configured folder | {FOOTER}")
        else:
            e.description = "No new attachments found."
            if result["skipped"]:
                e.set_footer(text=f"{result['skipped']} attachment(s) were "
                                  f"already downloaded | {FOOTER}")
        return e

    def _error_embed(self, username, ex):
        e = Theme.embed(title="Telegram Check Failed", color=Theme.RED)
        e.add_field(name="Channel", value=f"@{username}", inline=True)
        e.add_field(name="Reason", value=self._friendly(ex)[:500],
                    inline=False)
        return e

    async def _run_check(self, ctx, row):
        async with ctx.typing():
            try:
                result = await self._check_channel(row)
            except Exception as ex:
                return await ctx.reply(
                    embed=self._error_embed(row["username"], ex),
                    mention_author=False)
        await ctx.reply(embed=self._result_embed(row["username"], result),
                        mention_author=False)

    def _list_embed(self):
        rows = self.db.list_channels()
        if not rows:
            return None
        e = Theme.embed(title="Configured Telegram Channels",
                        color=Theme.MIDNIGHT)
        sel = self._selected()
        for r in rows:
            checked = (r["last_check"] or "never")[:19].replace("T", " ")
            state = "enabled" if r["enabled"] else "disabled"
            name = f"@{r['username']}"
            if r["username"] == sel:
                name += " (selected)"
            e.add_field(name=name,
                        value=f"Title: {r['title'] or 'unknown'}\n"
                              f"Status: {state} | Last check: {checked}",
                        inline=False)
        return e

    async def _status_embed(self):
        ok, reason = self._ready()
        if ok:
            try:
                await self._get_client()
                conn = "connected and authorized"
            except Exception as ex:
                conn = self._friendly(ex)[:200]
        else:
            conn = f"not configured ({reason})"
        enabled = self.db.get_setting("enabled", "0") == "1"
        auto_on = self.db.get_setting("auto_enabled", "0") == "1"
        running = self.auto_loop.is_running()
        e = Theme.embed(title="Telegram Downloader Status",
                       color=Theme.MIDNIGHT)
        e.add_field(name="Connection", value=conn)
        e.add_field(name="Feature", value="enabled" if enabled else "disabled")
        e.add_field(name="Automatic monitoring",
                    value=f"{'on' if auto_on else 'off'} | "
                          f"interval {self._auto_interval()} min | "
                          f"{'running' if running else 'stopped'}")
        e.add_field(name="Configured channels",
                    value=str(len(self.db.list_channels())))
        e.add_field(name="Selected channel",
                    value=f"@{self._selected()}" if self._selected()
                    else "none")
        e.add_field(name="Download folder", value=str(self._folder()))
        e.add_field(name="Posts per first check", value=str(self._posts()))
        return e

    def _recent_pages(self, rows):
        pages = []
        for i in range(0, len(rows), 5):
            chunk = rows[i:i + 5]
            e = Theme.embed(title="Recently Downloaded Files",
                            color=Theme.MIDNIGHT)
            for r in chunk:
                when = (r["downloaded_at"] or "")[:19].replace("T", " ")
                chan = f"@{r['username']}" if r["username"] else "unknown"
                e.add_field(name=r["filename"] or "unnamed file",
                            value=f"Size: {_hsize(r['file_size'])} | "
                                  f"Channel: {chan} | {when}",
                            inline=False)
            e.set_footer(text=f"Page {len(pages) + 1} | {FOOTER}")
            pages.append(e)
        return pages

    # ---- optional background monitoring ----

    @tasks.loop(minutes=15)
    async def auto_loop(self):
        ok, _ = self._ready()
        if not ok:
            self.stop_auto()
            return
        try:
            for row in self.db.enabled_channels():
                try:
                    result = await self._check_channel(row)
                    log.info("Auto check @%s: %s new, %s skipped",
                             row["username"], len(result["found"]),
                             result["skipped"])
                except Exception as ex:
                    log.error("Auto check failed for @%s: %s",
                              row["username"], ex)
                await asyncio.sleep(3)
        except Exception as ex:
            log.error("Automatic monitoring pass failed: %s", ex)

    @auto_loop.before_loop
    async def _before_auto_loop(self):
        await self.bot.wait_until_ready()

    def start_auto(self):
        self.auto_loop.change_interval(minutes=self._auto_interval())
        if not self.auto_loop.is_running():
            self.auto_loop.start()
            log.info("Automatic monitoring started (%s min)",
                     self._auto_interval())

    def stop_auto(self):
        if self.auto_loop.is_running():
            self.auto_loop.stop()
            log.info("Automatic monitoring stopped")

    # ================= commands =================

    @commands.group(name="tg", invoke_without_command=True)
    async def tg(self, ctx):
        ok, reason = self._ready()
        e = Theme.embed(title="Telegram Downloader",
                        description="Select an option below, or use the "
                                    "subcommands listed in the help command.",
                        color=Theme.MIDNIGHT)
        if ok:
            e.add_field(name="Status", value="Configured and ready.",
                        inline=False)
        else:
            e.add_field(name="Status",
                        value=f"Unavailable: {reason}. Paste commands "
                              f"continue to work normally.", inline=False)
        await ctx.reply(embed=e, view=TgMenuView(self, ctx.author.id),
                        mention_author=False)

    @tg.command(name="list")
    async def tg_list(self, ctx):
        e = self._list_embed()
        if e is None:
            return await ctx.reply("No Telegram channels are configured. An "
                                   "administrator can add one with "
                                   f"{PREFIX}tg add @channelname.",
                                   mention_author=False)
        view = None
        if self._ready()[0] and (ctx.author.id == OWNER_ID
                                 or is_admin(ctx.author.id)):
            if self.db.list_channels():
                view = ChannelSelectView(self)
        await ctx.reply(embed=e, view=view, mention_author=False)

    @tg.command(name="status")
    async def tg_status(self, ctx):
        await ctx.reply(embed=await self._status_embed(),
                        mention_author=False)

    @tg.command(name="recent")
    async def tg_recent(self, ctx, count: int = 10):
        count = max(1, min(50, count))
        rows = self.db.recent(count)
        if not rows:
            return await ctx.reply("No files have been downloaded yet.",
                                   mention_author=False)
        await paginate(ctx, self._recent_pages(rows))

    @tg.command(name="stats")
    async def tg_stats(self, ctx):
        total, per, failed = self.db.stats()
        e = Theme.embed(title="Download Statistics", color=Theme.MIDNIGHT)
        e.add_field(name="Files downloaded", value=str(total["c"]))
        e.add_field(name="Total size", value=_hsize(total["s"]))
        e.add_field(name="Failed downloads", value=str(failed))
        if total["last"]:
            e.add_field(name="Last download",
                        value=(total["last"] or "")[:19].replace("T", " "))
        if per:
            lines = [f"@{r['username']}: {r['c']} files ({_hsize(r['s'])})"
                     for r in per[:10]]
            e.add_field(name="Per channel", value="\n".join(lines),
                        inline=False)
        await ctx.reply(embed=e, mention_author=False)

    @tg.command(name="folder")
    async def tg_folder(self, ctx):
        await ctx.reply(f"Current download folder: {self._folder()}",
                        mention_author=False)

    @tg.command(name="add")
    @admin_only()
    @commands.cooldown(1, 20.0, commands.BucketType.user)
    async def tg_add(self, ctx, channel: str):
        if not await self._require_config(ctx):
            return
        username = self._clean(channel)
        if not username:
            return await ctx.reply("Please provide a valid Telegram channel "
                                   f"username, for example {PREFIX}tg add "
                                   "@examplechannel.", mention_author=False)
        if self.db.get_channel(username):
            return await ctx.reply("That channel is already configured.",
                                   mention_author=False)
        async with ctx.typing():
            try:
                client = await self._get_client()
                entity = await self._resolve_entity(client, username)
                title = getattr(entity, "title", None) or username
                channel_id = utils.get_peer_id(entity)
            except Exception as ex:
                return await ctx.reply(
                    embed=self._error_embed(username, ex),
                    mention_author=False)
        self.db.add_channel(channel_id, username, title)
        await ctx.reply(f"Channel @{username} added. On its first check, up "
                        f"to {self._posts()} recent posts will be scanned. "
                        f"Use {PREFIX}tg select @{username} to check it now.",
                        mention_author=False)

    @tg.command(name="remove")
    @admin_only()
    async def tg_remove(self, ctx, channel: str):
        username = self._clean(channel)
        row = self.db.get_channel(username) if username else None
        if row is None:
            return await ctx.reply("That channel is not configured.",
                                   mention_author=False)
        view = ConfirmView(ctx.author.id)
        msg = await ctx.reply(f"Remove Telegram channel @{username}? "
                              f"Download history will be kept.",
                              view=view, mention_author=False)
        await view.wait()
        if view.value:
            self.db.remove_channel(username)
            if self._selected() == username:
                self.db.set_setting("selected_channel", "")
            await msg.edit(content=f"Channel @{username} removed.",
                           view=None)
        else:
            await msg.edit(content="Action cancelled or timed out.",
                           view=None)

    @tg.command(name="select")
    @admin_only()
    @commands.cooldown(1, 30.0, commands.BucketType.user)
    async def tg_select(self, ctx, channel: str):
        if not await self._require_config(ctx):
            return
        username = self._clean(channel)
        if not username:
            return await ctx.reply("Please provide a channel username, for "
                                   f"example {PREFIX}tg select "
                                   "@examplechannel.", mention_author=False)
        row = self.db.get_channel(username)
        if row is None:
            return await ctx.reply("That channel is not configured. Add it "
                                   f"first with {PREFIX}tg add @{username}.",
                                   mention_author=False)
        self.db.set_setting("selected_channel", username)
        await self._run_check(ctx, row)

    @tg.command(name="check")
    @admin_only()
    @commands.cooldown(1, 30.0, commands.BucketType.user)
    async def tg_check(self, ctx, channel: str = None):
        if not await self._require_config(ctx):
            return
        username = self._clean(channel) if channel else self._selected()
        if not username:
            return await ctx.reply("Specify a channel, for example "
                                   f"{PREFIX}tg check @examplechannel, or "
                                   "select one first.", mention_author=False)
        row = self.db.get_channel(username)
        if row is None:
            return await ctx.reply("That channel is not configured.",
                                   mention_author=False)
        await self._run_check(ctx, row)

    @tg.command(name="login")
    @owner_only()
    async def tg_login(self, ctx):
        if not await self._require_config(ctx):
            return
        if ctx.guild is not None:
            return await ctx.reply("For security, this command must be used "
                                   "in the bot's DMs.", mention_author=False)

        def check(m):
            return m.author.id == ctx.author.id and m.guild is None

        await ctx.reply("Telegram login started. Enter your phone number "
                         "including the country code, for example "
                         "+15551234567. Type cancel to abort.",
                         mention_author=False)
        try:
            phone_msg = await self.bot.wait_for("message", check=check,
                                                timeout=180)
        except asyncio.TimeoutError:
            return await ctx.reply("Login cancelled: timed out.",
                                    mention_author=False)
        phone = phone_msg.content.strip()
        if phone.lower() == "cancel":
            return await ctx.reply("Login cancelled.", mention_author=False)
        try:
            api_id = int(TG_API_ID)
            client = TelegramClient(TG_SESSION, api_id, TG_API_HASH)
            await client.connect()
            if await client.is_user_authorized():
                self.client = client
                return await ctx.reply("This session is already authorized. "
                                        "No further action is needed.",
                                        mention_author=False)
            await client.send_code_request(phone)
        except Exception as ex:
            return await ctx.reply(f"Login failed: {self._friendly(ex)}",
                                    mention_author=False)
        await ctx.reply("Enter the login code that Telegram sent to your "
                         "app. Type cancel to abort.", mention_author=False)
        try:
            code_msg = await self.bot.wait_for("message", check=check,
                                                timeout=180)
        except asyncio.TimeoutError:
            return await ctx.reply("Login cancelled: timed out.",
                                    mention_author=False)
        code = code_msg.content.strip()
        if code.lower() == "cancel":
            return await ctx.reply("Login cancelled.", mention_author=False)
        try:
            await client.sign_in(phone=phone, code=code)
        except SessionPasswordNeededError:
            await ctx.reply("Two-factor authentication is enabled. Enter "
                             "your Telegram password. Type cancel to abort.",
                             mention_author=False)
            try:
                pw_msg = await self.bot.wait_for("message", check=check,
                                                  timeout=180)
            except asyncio.TimeoutError:
                return await ctx.reply("Login cancelled: timed out.",
                                        mention_author=False)
            pw = pw_msg.content.strip()
            if pw.lower() == "cancel":
                return await ctx.reply("Login cancelled.",
                                        mention_author=False)
            try:
                await client.sign_in(password=pw)
            except Exception as ex:
                return await ctx.reply(f"Login failed: {self._friendly(ex)}",
                                        mention_author=False)
        except Exception as ex:
            return await ctx.reply(f"Login failed: {self._friendly(ex)}",
                                    mention_author=False)
        self.client = client
        me = await client.get_me()
        await ctx.reply(f"Login successful. You are logged in as "
                         f"{me.first_name}. The session file has been saved. "
                         f"Do not share it.", mention_author=False)

    @tg.command(name="setfolder")
    @admin_only()
    async def tg_setfolder(self, ctx, *, path: str):
        raw = path.strip().strip('"')
        if not raw:
            return await ctx.reply(f"Usage: {PREFIX}tg setfolder <path>",
                                   mention_author=False)
        try:
            p = Path(raw)
            if p.exists() and not p.is_dir():
                return await ctx.reply("That path exists but is not a "
                                       "folder.", mention_author=False)
            p.mkdir(parents=True, exist_ok=True)
        except OSError as ex:
            return await ctx.reply(f"The folder could not be created: {ex}",
                                   mention_author=False)
        self.db.set_setting("download_dir", str(p.resolve()))
        await ctx.reply(f"Download folder set to: {p.resolve()}",
                        mention_author=False)

    @tg.command(name="setposts")
    @admin_only()
    async def tg_setposts(self, ctx, count: int):
        if not 1 <= count <= 100:
            return await ctx.reply("Choose a value between 1 and 100.",
                                   mention_author=False)
        self.db.set_setting("posts", str(count))
        await ctx.reply(f"Newly added channels will scan up to {count} "
                        f"recent posts on their first check.",
                        mention_author=False)

    @tg.command(name="start")
    @admin_only()
    async def tg_start(self, ctx):
        self.db.set_setting("enabled", "1")
        auto = self.db.get_setting("auto_enabled", "0") == "1"
        if auto and self._ready()[0]:
            self.start_auto()
        await ctx.reply("Telegram downloader enabled." +
                        (" Background monitoring is running." if
                         self.auto_loop.is_running() else
                         f" Background monitoring is off; use {PREFIX}tg "
                         "auto on to enable it."),
                        mention_author=False)

    @tg.command(name="stop")
    @admin_only()
    async def tg_stop(self, ctx):
        self.stop_auto()
        self.db.set_setting("enabled", "0")
        await ctx.reply("Background monitoring stopped. Manual commands "
                        f"such as {PREFIX}tg select and {PREFIX}tg check "
                        "remain available.", mention_author=False)

    @tg.command(name="auto")
    @admin_only()
    async def tg_auto(self, ctx, action: str = "", value: int = None):
        a = action.lower()
        if a == "on":
            if not await self._require_config(ctx):
                return
            self.db.set_setting("auto_enabled", "1")
            self.db.set_setting("enabled", "1")
            self.start_auto()
            reply = (f"Automatic monitoring enabled. Every configured "
                     f"channel is checked every {self._auto_interval()} "
                     f"minutes.")
        elif a == "off":
            self.db.set_setting("auto_enabled", "0")
            self.stop_auto()
            reply = ("Automatic monitoring disabled. Manual checks still "
                     "work.")
        elif a == "interval":
            if value is None or not 1 <= value <= 1440:
                return await ctx.reply(f"Usage: {PREFIX}tg auto interval "
                                       "<minutes 1-1440>",
                                       mention_author=False)
            self.db.set_setting("auto_interval", str(value))
            if self.auto_loop.is_running():
                self.auto_loop.change_interval(minutes=value)
            reply = f"Monitoring interval set to {value} minutes."
        else:
            reply = (f"Usage: {PREFIX}tg auto on | {PREFIX}tg auto off | "
                     f"{PREFIX}tg auto interval <minutes>")
        await ctx.reply(reply, mention_author=False)


async def setup(bot):
    await bot.add_cog(TelegramCog(bot))
    log.info("Telegram module ready")