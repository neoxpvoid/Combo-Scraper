# Main entry: theme, shared UI, help, error handling. Loads paste.py and tg.py.

import asyncio
import logging
import os
import sqlite3

import discord
from discord.ext import commands
from dotenv import load_dotenv

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("bot")

load_dotenv()

TOKEN = os.getenv("DISCORD_TOKEN")
OWNER_ID = int(os.getenv("OWNER_ID", "0") or 0)
PREFIX = os.getenv("COMMAND_PREFIX", "!")
MAIN_DB = os.getenv("MAIN_DB", "pasteview.db")

if not TOKEN:
    raise SystemExit("DISCORD_TOKEN missing in .env")

FOOTER = "Made with ❤"


class Theme:
    MIDNIGHT = discord.Color.from_rgb(10, 10, 18)      # midnight black
    TWILIGHT = discord.Color.from_rgb(108, 140, 255)   # twilight blue
    RED = discord.Color.from_rgb(229, 72, 77)
    GREEN = discord.Color.from_rgb(64, 176, 120)

    @classmethod
    def embed(cls, title=None, description=None, color=None):
        e = discord.Embed(title=title, description=description,
                          color=color or cls.TWILIGHT)
        e.set_footer(text=FOOTER)
        return e


intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix=commands.when_mentioned_or(PREFIX),
                   intents=intents, help_command=None, case_insensitive=True)


def is_admin(uid) -> bool:
    try:
        con = sqlite3.connect(MAIN_DB)
        try:
            row = con.execute("SELECT 1 FROM admins WHERE user_id=?",
                              (str(uid),)).fetchone()
        finally:
            con.close()
        return row is not None
    except Exception:
        return False


def display_name(ctx, uid):
    member = ctx.guild.get_member(uid) if ctx.guild else None
    return member.display_name if member else f"ID {uid}"


def owner_only():
    async def predicate(ctx):
        return ctx.author.id == OWNER_ID
    return commands.check(predicate)


def admin_only():
    async def predicate(ctx):
        return ctx.author.id == OWNER_ID or is_admin(ctx.author.id)
    return commands.check(predicate)


def telegram_state():
    try:
        import importlib.util
        installed = importlib.util.find_spec("telethon") is not None
    except Exception:
        installed = False
    if not installed:
        return False, "the telethon library is not installed (run: pip install telethon)"
    if not (os.getenv("TELEGRAM_API_ID", "").strip()
            and os.getenv("TELEGRAM_API_HASH", "").strip()):
        return False, "TELEGRAM_API_ID and TELEGRAM_API_HASH are missing in the .env file"
    return True, ""


class ConfirmView(discord.ui.View):
    def __init__(self, user_id, timeout=60):
        super().__init__(timeout=timeout)
        self.user_id = user_id
        self.value = None

    async def interaction_check(self, interaction):
        if interaction.user.id != self.user_id:
            await interaction.response.send_message(
                "Only the user who started this action can respond.",
                ephemeral=True)
            return False
        return True

    @discord.ui.button(label="Confirm", style=discord.ButtonStyle.success)
    async def confirm(self, interaction, button):
        self.value = True
        for b in self.children:
            b.disabled = True
        await interaction.response.edit_message(view=self)
        self.stop()

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction, button):
        self.value = False
        for b in self.children:
            b.disabled = True
        await interaction.response.edit_message(view=self)
        self.stop()


class Paginator(discord.ui.View):
    def __init__(self, user_id, pages, timeout=180):
        super().__init__(timeout=timeout)
        self.user_id = user_id
        self.pages = pages
        self.index = 0
        self.message = None

    @property
    def current(self):
        return self.pages[self.index]

    async def interaction_check(self, interaction):
        if interaction.user.id != self.user_id:
            await interaction.response.send_message(
                "This view belongs to another user.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="Previous", style=discord.ButtonStyle.secondary)
    async def prev(self, interaction, button):
        self.index = (self.index - 1) % len(self.pages)
        await interaction.response.edit_message(embed=self.current, view=self)

    @discord.ui.button(label="Next", style=discord.ButtonStyle.primary)
    async def next(self, interaction, button):
        self.index = (self.index + 1) % len(self.pages)
        await interaction.response.edit_message(embed=self.current, view=self)

    async def on_timeout(self):
        for b in self.children:
            b.disabled = True
        if self.message:
            try:
                await self.message.edit(view=self)
            except Exception:
                pass


async def paginate(ctx, pages):
    if len(pages) == 1:
        return await ctx.reply(embed=pages[0], mention_author=False)
    view = Paginator(ctx.author.id, pages)
    view.message = await ctx.reply(embed=view.current, view=view,
                                   mention_author=False)


@bot.event
async def on_ready():
    log.info("Logged in as %s", bot.user)
    await bot.change_presence(activity=discord.Activity(
        type=discord.ActivityType.watching, name="PasteView"))


@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        return
    if isinstance(error, commands.CommandOnCooldown):
        return await ctx.reply(
            f"This command is on cooldown. Try again in "
            f"{error.retry_after:.0f} seconds.", mention_author=False)
    if isinstance(error, commands.CheckFailure):
        return await ctx.reply("You do not have permission to use this command.",
                               mention_author=False)
    if isinstance(error, commands.MissingRequiredArgument):
        return await ctx.reply(f"A required argument is missing. See {PREFIX}help.",
                               mention_author=False)
    if isinstance(error, commands.BadArgument):
        return await ctx.reply(f"Invalid argument. See {PREFIX}help.",
                               mention_author=False)
    log.error("Command error in %s: %s", ctx.command, error)
    await ctx.reply("An error occurred while running this command. "
                    "It has been logged.", mention_author=False)


@bot.command(name="help")
async def help_cmd(ctx):
    is_owner = ctx.author.id == OWNER_ID
    admin = is_owner or is_admin(ctx.author.id)
    tg_ok, tg_reason = telegram_state()
    e = Theme.embed(title="Command Reference", color=Theme.MIDNIGHT)
    e.add_field(name="Everyone", value=(
        f"`{PREFIX}latest [id]` / `{PREFIX}download [id]` — newest paste as combo.txt\n"
        f"`{PREFIX}search <words>` — search paste titles\n"
        f"`{PREFIX}links` — monitored profiles\n"
        f"`{PREFIX}paste <url>` — fetch a paste by URL\n"
        f"`{PREFIX}ping` — bot latency\n"
        f"`{PREFIX}tg` — Telegram downloader menu"), inline=False)
    if admin:
        e.add_field(name="Administrator", value=(
            f"`{PREFIX}checknow` — run the scheduled paste check now\n"
            f"`{PREFIX}history` — delivered pastes\n"
            f"`{PREFIX}inspect [id]` / `{PREFIX}dumphtml [id]` — diagnostics\n"
            f"`{PREFIX}keywords` / `{PREFIX}status` / `{PREFIX}admins`\n"
            f"`{PREFIX}restartbrowser`\n"
            f"`{PREFIX}tg add/select/check <@channel>` — Telegram actions\n"
            f"`{PREFIX}tg setfolder <path>` / `{PREFIX}tg auto <on|off|interval n>`"),
            inline=False)
    if is_owner:
        e.add_field(name="Owner", value=(
            f"`{PREFIX}addkeyword` / `{PREFIX}removekeyword` / `{PREFIX}setoffset` / `{PREFIX}setpattern`\n"
            f"`{PREFIX}addadmin` / `{PREFIX}removeadmin`\n"
            f"`{PREFIX}addlink` / `{PREFIX}removelink` / `{PREFIX}setchannel` / `{PREFIX}setinterval`\n"
            f"`{PREFIX}pause` / `{PREFIX}resume`\n"
            f"`{PREFIX}tg login` (in DMs) / `{PREFIX}tg remove` / `{PREFIX}tg setposts`"),
            inline=False)
    if tg_ok:
        e.add_field(name="Telegram", value="Configured and ready.", inline=False)
    else:
        e.add_field(name="Telegram",
                    value=f"Unavailable: {tg_reason}. "
                          f"Paste commands are unaffected.",
                    inline=False)
    await ctx.reply(embed=e, mention_author=False)


@bot.command()
async def ping(ctx):
    await ctx.reply(f"Pong. Gateway latency: "
                    f"{round(bot.latency * 1000)} ms.", mention_author=False)


async def main():
    for ext in ("paste", "tg"):
        try:
            await bot.load_extension(ext)
            log.info("Loaded extension: %s", ext)
        except Exception as ex:
            log.error("Could not load extension %s: %s", ext, ex)
    await bot.start(TOKEN)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass