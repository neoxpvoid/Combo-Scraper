# PasteView module: profile monitoring, 45-minute checks, duplicate
# protection, combo.txt delivery with buttons.

import asyncio
import io
import logging
import os
import re
import sqlite3
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urljoin, urlparse, unquote

import discord
from discord.ext import commands, tasks
from dotenv import load_dotenv
from playwright.async_api import async_playwright

from bot import (FOOTER, OWNER_ID, PREFIX, ConfirmView, Paginator, Theme,
                 admin_only, display_name, is_admin, owner_only, paginate)

log = logging.getLogger("paste")
load_dotenv()

DEFAULT_CHANNEL = os.getenv("CHANNEL_ID", "")
DEFAULT_LINK = os.getenv(
    "DEFAULT_LINK",
    "https://pasteview.com/user/profile/68a5f93950e5300d40cbe9b1")
DEFAULT_PATTERN = os.getenv("PASTE_PATTERN", "")

_headless = os.getenv("HEADLESS", "").strip().lower()
if _headless in ("1", "true", "yes"):
    HEADLESS = True
elif _headless in ("0", "false", "no"):
    HEADLESS = False
else:
    HEADLESS = not os.getenv("DISPLAY")

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")

COMBO_DIR = Path("downloads")
COMBO_NAME = "combo.txt"
MAX_UPLOAD = 8 * 1024 * 1024

if os.name != "nt" and not os.environ.get("PLAYWRIGHT_BROWSERS_PATH"):
    os.environ["PLAYWRIGHT_BROWSERS_PATH"] = \
        str(Path.home() / ".cache" / "ms-playwright")

CHROMIUM_ARGS = ["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu",
                 "--disable-blink-features=AutomationControlled"]


class DB:
    def __init__(self, path="pasteview.db"):
        self.con = sqlite3.connect(path)
        self.con.row_factory = sqlite3.Row
        with self.con:
            self.con.execute("""CREATE TABLE IF NOT EXISTS admins(
                user_id TEXT PRIMARY KEY, added_by TEXT, added_at TEXT)""")
            self.con.execute("""CREATE TABLE IF NOT EXISTS links(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                url TEXT UNIQUE NOT NULL, label TEXT DEFAULT '',
                last_paste_url TEXT DEFAULT '', last_check TEXT DEFAULT '')""")
            self.con.execute("""CREATE TABLE IF NOT EXISTS settings(
                key TEXT PRIMARY KEY, value TEXT)""")
            self.con.execute("""CREATE TABLE IF NOT EXISTS keywords(
                word TEXT PRIMARY KEY)""")
            self.con.execute("""CREATE TABLE IF NOT EXISTS sent_pastes(
                url TEXT PRIMARY KEY, title TEXT DEFAULT '',
                link_id INTEGER, sent_at TEXT)""")

    def add_admin(self, uid, by):
        with self.con:
            self.con.execute("INSERT OR IGNORE INTO admins VALUES (?,?,?)",
                (str(uid), str(by),
                 datetime.now(timezone.utc).isoformat(timespec="seconds")))

    def remove_admin(self, uid) -> bool:
        with self.con:
            cur = self.con.execute("DELETE FROM admins WHERE user_id=?",
                                   (str(uid),))
        return cur.rowcount > 0

    def is_admin(self, uid) -> bool:
        return self.con.execute("SELECT 1 FROM admins WHERE user_id=?",
                                (str(uid),)).fetchone() is not None

    def list_admins(self):
        return self.con.execute("SELECT * FROM admins ORDER BY added_at").fetchall()

    def add_keyword(self, word):
        with self.con:
            self.con.execute("INSERT OR IGNORE INTO keywords(word) VALUES (?)",
                             (word.strip().lower(),))

    def remove_keyword(self, word) -> bool:
        with self.con:
            cur = self.con.execute("DELETE FROM keywords WHERE word=?",
                                   (word.strip().lower(),))
        return cur.rowcount > 0

    def list_keywords(self):
        return [r["word"] for r in
                self.con.execute("SELECT word FROM keywords ORDER BY word")]

    def mark_sent(self, url, title="", link_id=None):
        with self.con:
            self.con.execute(
                "INSERT OR IGNORE INTO sent_pastes(url,title,link_id,sent_at) "
                "VALUES (?,?,?,?)",
                (url, title or "", link_id,
                 datetime.now(timezone.utc).isoformat(timespec="seconds")))

    def unmark_sent(self, url):
        with self.con:
            self.con.execute("DELETE FROM sent_pastes WHERE url=?", (url,))

    def was_sent(self, url) -> bool:
        return self.con.execute("SELECT 1 FROM sent_pastes WHERE url=?",
                                (url,)).fetchone() is not None

    def sent_history(self, limit=10):
        return self.con.execute(
            "SELECT * FROM sent_pastes ORDER BY sent_at DESC LIMIT ?",
            (limit,)).fetchall()

    def sent_count(self) -> int:
        return self.con.execute(
            "SELECT COUNT(*) AS c FROM sent_pastes").fetchone()["c"]

    def add_link(self, url, label="") -> bool:
        with self.con:
            cur = self.con.execute(
                "INSERT OR IGNORE INTO links(url, label) VALUES (?,?)",
                (url, label))
        return cur.rowcount > 0

    def remove_link(self, lid) -> bool:
        with self.con:
            cur = self.con.execute("DELETE FROM links WHERE id=?", (lid,))
        return cur.rowcount > 0

    def get_links(self):
        return self.con.execute("SELECT * FROM links ORDER BY id").fetchall()

    def get_link(self, lid):
        return self.con.execute("SELECT * FROM links WHERE id=?",
                                (lid,)).fetchone()

    def get_link_by_url(self, url):
        return self.con.execute("SELECT * FROM links WHERE url=?",
                                (url,)).fetchone()

    def set_last(self, lid, paste_url):
        with self.con:
            self.con.execute(
                "UPDATE links SET last_paste_url=?, last_check=? WHERE id=?",
                (paste_url,
                 datetime.now(timezone.utc).isoformat(timespec="seconds"), lid))

    def set_setting(self, key, value):
        with self.con:
            self.con.execute(
                "INSERT OR REPLACE INTO settings(key,value) VALUES (?,?)",
                (key, str(value)))

    def get_setting(self, key, default=None):
        row = self.con.execute("SELECT value FROM settings WHERE key=?",
                               (key,)).fetchone()
        return row["value"] if row else default

    def del_setting(self, key):
        with self.con:
            self.con.execute("DELETE FROM settings WHERE key=?", (key,))


db = DB()

SOCIAL_HINTS = ("t.me", "telegram", "discord", "whatsapp", "facebook.com",
                "twitter.com", "instagram.com", "linkedin.com", "youtube.com",
                "youtu.be", "tiktok", "pinterest.com", "vk.com", "mailto:",
                "skype:", "/share", "share?", "tweet")

NAV_EXCLUDE = ("/user", "/new", "/login", "/register", "/logout",
               "/settings", "/admin", "/api", "/terms", "/privacy")

TITLE_SELECTORS = [
    "table tbody a", "table a",
    "a[href*='/paste']", "a[href*='/view']", "a[href*='/raw']",
    ".list-group a",
]

BLOCK_SELECTORS = [
    "pre", "textarea", "code",
    "[class*='paste']", "[id*='paste']",
    "[class*='content']", ".card-body", ".well", ".panel-body",
]

RAW_LINK_HINTS = ("raw", "download", "direct", "plain")

DOWNLOAD_HINTS = ("download", "save", "raw", "grab", "export", "get file")
_DOWNLOAD_RE = re.compile("(" + "|".join(re.escape(h) for h in DOWNLOAD_HINTS)
                          + r"|\bdl\b|\.txt)", re.I)


def is_social(url: str) -> bool:
    if not url:
        return False
    u = unquote(url).lower()
    if any(h in u for h in SOCIAL_HINTS):
        return True
    try:
        if urlparse(u).netloc in ("x.com", "www.x.com"):
            return True
    except Exception:
        pass
    return False


def same_site(url_a: str, url_b: str) -> bool:
    try:
        return urlparse(url_a).netloc.lower() == urlparse(url_b).netloc.lower()
    except Exception:
        return False


def _norm_url(base, href):
    if not href or href.startswith("#") or href.startswith("javascript"):
        return None
    full = urljoin(base, href)
    if is_social(full):
        return None
    if not same_site(full, base):
        return None
    if any(x in full for x in NAV_EXCLUDE):
        return None
    return full


def _pattern_matches(url: str) -> bool:
    pat = db.get_setting("paste_pattern")
    if not pat:
        return True
    try:
        if re.search(pat, url):
            return True
    except re.error:
        pass
    return pat.lower() in url.lower()


def _keyword_matches(title: str) -> bool:
    kws = db.list_keywords()
    if not kws:
        return True
    t = (title or "").lower()
    return any(k in t for k in kws)


def _get_offset() -> int:
    try:
        return max(0, int(db.get_setting("paste_offset", "0") or 0))
    except ValueError:
        return 0


async def _in_chrome(el) -> bool:
    try:
        return bool(await el.evaluate(
            "e => !!(e.closest('nav, header, footer, .navbar, .nav, .menu'))"))
    except Exception:
        return False


async def _views_for(el):
    try:
        text = await el.evaluate(
            "e => (e.closest('tr') || e.closest('li') || "
            "e.closest('.list-group-item') || e.parentElement).innerText")
        nums = re.findall(r"[\d,]+", text or "")
        if nums:
            return nums[-1]
    except Exception:
        pass
    return None


async def collect_paste_links(page, base_url):
    found, seen = [], set()

    async def add(el):
        try:
            href = await el.get_attribute("href")
            title = (await el.inner_text() or "").strip()
        except Exception:
            return
        if not href or not title:
            return
        if title.replace(",", "").replace(".", "").replace(" ", "").isdigit():
            return
        full = _norm_url(base_url, href)
        if not full or full in seen:
            return
        if urlparse(full).path in ("", "/"):
            return
        seen.add(full)
        found.append({"title": title, "url": full,
                      "views": await _views_for(el)})

    rows = []
    for sel in ("table tbody tr", "table tr", ".list-group-item", "tr"):
        try:
            rows = await page.query_selector_all(sel)
        except Exception:
            rows = []
        if rows:
            break
    for row in rows:
        try:
            links = await row.query_selector_all("a")
        except Exception:
            continue
        for el in links:
            await add(el)

    if not found:
        for sel in TITLE_SELECTORS:
            try:
                els = await page.query_selector_all(sel)
            except Exception:
                continue
            for el in els:
                await add(el)
            if found:
                break

    if not found:
        try:
            els = await page.query_selector_all("a")
        except Exception:
            els = []
        for el in els:
            if await _in_chrome(el):
                continue
            await add(el)

    if db.get_setting("paste_pattern"):
        found = [p for p in found if _pattern_matches(p["url"])]
    if db.list_keywords():
        found = [p for p in found if _keyword_matches(p["title"])]
    offset = _get_offset()
    if offset > 0:
        found = found[offset:]

    return found


async def _goto_and_settle(page, url):
    await page.goto(url, wait_until="domcontentloaded", timeout=60000)
    try:
        await page.wait_for_load_state("networkidle", timeout=15000)
    except Exception:
        pass
    await page.wait_for_timeout(1500)


async def get_top_paste(page, profile_url):
    await _goto_and_settle(page, profile_url)
    links = await collect_paste_links(page, profile_url)
    if not links:
        return None
    return links[0]


async def _save_download(download):
    try:
        COMBO_DIR.mkdir(exist_ok=True)
        await download.save_as(str(COMBO_DIR / COMBO_NAME))
        data = (COMBO_DIR / COMBO_NAME).read_bytes()
        text = data.decode("utf-8", "ignore").strip()
        return text if len(text) > 20 else None
    except Exception as ex:
        log.error("Saving download failed: %s", ex)
        return None


async def _download_candidates(target):
    try:
        els = await target.query_selector_all(
            "button, a, [role='button'], [class*='download'], [id*='download']")
    except Exception:
        return []
    cands = []
    for el in els:
        try:
            href = (await el.get_attribute("href") or "").strip()
            text = (await el.inner_text() or "").strip()
            cls = (await el.get_attribute("class") or "")
            cid = (await el.get_attribute("id") or "")
            ttip = (await el.get_attribute("title") or "")
            aria = (await el.get_attribute("aria-label") or "")
        except Exception:
            continue
        blob = f"{text} {cls} {cid} {ttip} {aria} {href}"
        if not blob.strip():
            continue
        if is_social(href or blob):
            continue
        if href.startswith("http") and not same_site(href, target.url):
            continue
        href_raw = bool(re.search(r"(\.txt($|\?)|/download|/dl/|/raw)",
                                  href.lower()))
        if not (_DOWNLOAD_RE.search(blob) or href_raw):
            continue
        low = blob.lower()
        score = 0
        if "download" in low:
            score += 10
        if href_raw:
            score += 6
        if "raw" in low:
            score += 3
        if text:
            score += 2
        cands.append((el, score))
    cands.sort(key=lambda x: -x[1])
    return cands[:8]


async def click_download_button(target):
    cands = await _download_candidates(target)
    if not cands:
        return None
    known = set(target.context.pages)
    for el, score in cands:
        try:
            if not await el.is_visible():
                continue
        except Exception:
            continue
        try:
            async with target.expect_download(timeout=8000) as dl_info:
                await el.click()
            download = await dl_info.value
            text = await _save_download(download)
            if text:
                return text
        except Exception:
            pass
        try:
            await target.wait_for_timeout(1500)
            for p in [p for p in target.context.pages if p not in known]:
                try:
                    t = await try_fetch_raw(p, p.url) \
                        or await best_text_block(p)
                    if t and len(t) > 50:
                        return t
                except Exception:
                    pass
                finally:
                    try:
                        await p.close()
                    except Exception:
                        pass
            t = await best_text_block(target)
            if t and len(t) > 150:
                return t
        except Exception:
            pass
    return None


async def find_raw_link(target):
    try:
        els = await target.query_selector_all("a")
    except Exception:
        return None
    for el in els:
        try:
            href = await el.get_attribute("href")
            text = (await el.inner_text() or "").strip().lower()
        except Exception:
            continue
        if not href or href.startswith("#") or href.startswith("javascript"):
            continue
        full = urljoin(target.url, href)
        if is_social(full) or not same_site(full, target.url):
            continue
        blob = (href + " " + text).lower()
        if any(h in blob for h in RAW_LINK_HINTS) \
                or href.lower().endswith((".txt", ".text")):
            if any(x in full for x in NAV_EXCLUDE):
                continue
            return full
    return None


async def best_text_block(target):
    best, best_score = "", 0
    for sel in BLOCK_SELECTORS:
        try:
            els = await target.query_selector_all(sel)
        except Exception:
            continue
        for el in els:
            try:
                txt = (await el.inner_text() or "").strip()
            except Exception:
                continue
            if len(txt) < 40:
                continue
            try:
                n_links = len(await el.query_selector_all("a"))
            except Exception:
                n_links = 0
            score = len(txt) - n_links * 120
            if score > best_score:
                best, best_score = txt, score
    return best


async def _find_title_element(page, paste):
    target_path = urlparse(paste["url"]).path.rstrip("/")
    fallback = None
    for cand in await page.query_selector_all("a"):
        try:
            href = await cand.get_attribute("href")
            text = (await cand.inner_text() or "").strip()
        except Exception:
            continue
        if not href or not text:
            continue
        full = _norm_url(page.url, href)
        if not full:
            continue
        if urlparse(full).path.rstrip("/") == target_path:
            return cand
        if fallback is None and paste.get("title") and text == paste["title"]:
            fallback = cand
    return fallback


async def click_and_extract(page, profile_url, paste):
    try:
        await _goto_and_settle(page, profile_url)
    except Exception:
        return None
    el = await _find_title_element(page, paste)
    if el is None:
        log.warning("Title link not found on the profile page")
        return None
    known = set(page.context.pages)
    try:
        async with page.expect_download(timeout=6000) as dl_info:
            await el.click()
        download = await dl_info.value
    except Exception:
        download = None
    if download is not None:
        return await _save_download(download)
    await page.wait_for_timeout(2000)
    for p in [p for p in page.context.pages if p not in known]:
        try:
            t = await click_download_button(p) or await best_text_block(p)
            if t:
                return t
        except Exception:
            pass
        finally:
            try:
                await p.close()
            except Exception:
                pass
    try:
        t = await click_download_button(page)
        if t:
            return t
    except Exception:
        pass
    try:
        return await best_text_block(page)
    except Exception:
        return None


def raw_url_candidates(url: str):
    base = url.split("?")[0].rstrip("/")
    cands = [url]
    m = re.search(r"/(paste|view|p)/([A-Za-z0-9_-]+)", base)
    if m:
        seg, pid = m.group(0), m.group(2)
        cands += [base.replace(seg, f"/raw/{pid}"),
                  base.replace(seg, f"/download/{pid}"),
                  base.replace(seg, f"/dl/{pid}")]
    cands += [base + "/raw", base + "?raw=true"]
    return list(dict.fromkeys(cands))


async def try_fetch_raw(page, url):
    try:
        resp = await page.goto(url, wait_until="domcontentloaded", timeout=30000)
    except Exception:
        return None
    if resp is None or not resp.ok:
        return None
    try:
        ctype = (resp.headers or {}).get("content-type", "").lower()
    except Exception:
        ctype = ""
    if "html" in ctype:
        return None
    try:
        text = (await resp.text()).strip()
    except Exception:
        return None
    if len(text) > 20 and not text.startswith("<"):
        return text
    return None


async def extract_paste_content(page, paste, profile_url=None) -> str:
    paste_url = paste["url"]
    try:
        await _goto_and_settle(page, paste_url)
    except Exception as ex:
        log.error("Could not open paste page: %s", ex)

    text = await click_download_button(page)
    if text:
        log.info("Paste captured via download button")
        return text

    for cand in raw_url_candidates(paste_url):
        text = await try_fetch_raw(page, cand)
        if text:
            log.info("Paste found via raw endpoint: %s", cand)
            return text

    raw = await find_raw_link(page)
    if raw:
        text = await try_fetch_raw(page, raw)
        if text:
            log.info("Paste found via raw link: %s", raw)
            return text

    for frame in page.frames:
        try:
            text = await best_text_block(frame)
        except Exception:
            continue
        if text:
            log.info("Paste found via text-block detection")
            return text

    if profile_url:
        text = await click_and_extract(page, profile_url, paste)
        if text:
            log.info("Paste captured via title click and download button")
            return text
    return ""


async def _install_chromium():
    def _run():
        cmd = [sys.executable, "-m", "playwright", "install", "chromium"]
        log.info("Installing chromium (one time, ~170 MB)")
        return subprocess.run(cmd, capture_output=True, text=True, timeout=1800)
    try:
        res = await asyncio.to_thread(_run)
        if res.returncode == 0:
            log.info("Chromium installed")
            return True
        log.error("Chromium install failed:\n%s", (res.stderr or "")[-1500:])
    except Exception as ex:
        log.error("Chromium install failed: %s", ex)
    return False


class Scraper:
    def __init__(self):
        self.pw = None
        self.browser = None
        self._headless = None
        self.lock = asyncio.Lock()
        self.launch_lock = asyncio.Lock()

    async def _try_launch(self, headless: bool):
        try:
            browser = await self.pw.chromium.launch(headless=headless,
                                                     args=CHROMIUM_ARGS)
        except Exception as ex:
            if "Executable doesn't exist" in str(ex):
                log.warning("Chromium binary missing, downloading")
                if await _install_chromium():
                    browser = await self.pw.chromium.launch(
                        headless=headless, args=CHROMIUM_ARGS)
                    return browser
            raise
        return browser

    async def _launch(self):
        self.pw = await async_playwright().start()
        try:
            self.browser = await self._try_launch(HEADLESS)
            self._headless = HEADLESS
        except Exception as ex:
            if HEADLESS:
                raise
            log.error("Headed browser failed (%s), retrying headless", ex)
            self.browser = await self._try_launch(True)
            self._headless = True
        log.info("Browser launched (headless=%s)", self._headless)

    async def ensure(self):
        if self.browser and self.browser.is_connected:
            return
        async with self.launch_lock:
            if self.browser and self.browser.is_connected:
                return
            old = self.browser
            self.browser = None
            if old:
                try: await old.close()
                except Exception: pass
            if self.pw:
                try: await self.pw.stop()
                except Exception: pass
                self.pw = None
            await self._launch()

    async def new_page(self):
        await self.ensure()
        return await self.browser.new_page(user_agent=UA,
                                           viewport={"width": 1366,
                                                     "height": 900})

    async def restart(self):
        async with self.launch_lock:
            if self.browser:
                try: await self.browser.close()
                except Exception: pass
                self.browser = None
            if self.pw:
                try: await self.pw.stop()
                except Exception: pass
                self.pw = None
            await self._launch()

    async def stop(self):
        try:
            if self.browser: await self.browser.close()
        except Exception: pass
        try:
            if self.pw: await self.pw.stop()
        except Exception: pass
        self.browser = self.pw = None


scraper = Scraper()


async def fetch_latest(link):
    page = await scraper.new_page()
    try:
        top = await get_top_paste(page, link["url"])
        if top:
            top["content"] = await extract_paste_content(page, top, link["url"])
        return top
    finally:
        try: await page.close()
        except Exception: pass


async def check_for_new_pastes():
    new_pastes = []
    async with scraper.lock:
        for link in db.get_links():
            page = None
            try:
                page = await scraper.new_page()
                top = await get_top_paste(page, link["url"])
                if top is None:
                    log.warning("No pastes detected on link #%s", link["id"])
                    continue
                if top["url"] == (link["last_paste_url"] or ""):
                    db.set_last(link["id"], top["url"])
                    continue
                if db.was_sent(top["url"]):
                    log.info("Duplicate skipped (already sent): %s", top["url"])
                    db.set_last(link["id"], top["url"])
                    continue
                top["content"] = await extract_paste_content(page, top,
                                                              link["url"])
                if not (top.get("content") or "").strip():
                    log.info("Paste unavailable, not sent: %s", top["url"])
                    db.set_last(link["id"], top["url"])
                    continue
                top["link"] = link
                db.mark_sent(top["url"], top.get("title", ""), link["id"])
                new_pastes.append(top)
            except Exception as ex:
                log.error("Failed checking link #%s: %s", link["id"], ex)
            finally:
                if page:
                    try: await page.close()
                    except Exception: pass
    return new_pastes


async def deliver_new_pastes(pastes, channel):
    sent = 0
    for p in pastes:
        try:
            await send_paste(channel, p, header="New paste")
            db.set_last(p["link"]["id"], p["url"])
            sent += 1
        except Exception as ex:
            log.error("Failed sending %s: %s (will retry next check)",
                      p["url"], ex)
            db.unmark_sent(p["url"])
    return sent


def save_combo(content: str) -> Path:
    COMBO_DIR.mkdir(exist_ok=True)
    try:
        latest = COMBO_DIR / COMBO_NAME
        latest.write_text(content, encoding="utf-8", errors="ignore")
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        (COMBO_DIR / f"combo_{ts}.txt").write_text(
            content, encoding="utf-8", errors="ignore")
        return latest
    except Exception as ex:
        log.error("Saving combo.txt failed: %s", ex)
        return COMBO_DIR / COMBO_NAME


class PasteFileView(discord.ui.View):
    def __init__(self, paste):
        super().__init__(timeout=300)
        self.paste = paste

    def _file(self):
        data = (self.paste.get("content") or "").encode("utf-8", "ignore")
        return discord.File(io.BytesIO(data), filename=COMBO_NAME)

    def _embed(self):
        return Theme.embed(title=(self.paste.get("title") or "Paste")[:250],
                           color=Theme.GREEN)

    @discord.ui.button(label="Save to DMs", style=discord.ButtonStyle.primary)
    async def save_dm(self, interaction, button):
        if not (self.paste.get("content") or "").strip():
            return await interaction.response.send_message(
                "No file content is available for this paste.", ephemeral=True)
        try:
            await interaction.user.send(embed=self._embed(),
                                        file=self._file())
            await interaction.response.send_message(
                "The file has been sent to your DMs.", ephemeral=True)
        except discord.Forbidden:
            await interaction.response.send_message(
                "Your DMs are closed. Enable DMs from server members and "
                "try again.", ephemeral=True)

    @discord.ui.button(label="Resend file",
                       style=discord.ButtonStyle.secondary)
    async def resend(self, interaction, button):
        if not (self.paste.get("content") or "").strip():
            return await interaction.response.send_message(
                "No file content is available for this paste.", ephemeral=True)
        await interaction.response.send_message(embed=self._embed(),
                                                file=self._file())


async def send_paste(channel, paste, header="New paste"):
    src = paste.get("link")
    label = (src["label"] or f"Link #{src['id']}") if src else "PasteView"
    content = (paste.get("content") or "").strip()

    e = discord.Embed(title=(paste.get("title") or "Untitled paste")[:250],
                      color=Theme.GREEN,
                      timestamp=datetime.now(timezone.utc))
    e.set_author(name=f"{header} — {label}"[:256])

    footer = []
    if paste.get("views"):
        footer.append(f"Views: {paste['views']}")

    file, view, note = None, None, ""
    if content:
        save_combo(content)
        data = content.encode("utf-8", "ignore")
        if len(data) <= MAX_UPLOAD:
            file = discord.File(io.BytesIO(data), filename=COMBO_NAME)
            view = PasteFileView(paste)
            e.description = (f"Attachment: {COMBO_NAME}\n"
                             f"Size: {len(data) / 1024:.1f} KB\n"
                             f"Lines: {content.count(chr(10)) + 1:,}")
        else:
            note = (f"This paste is {len(data) / 1024 / 1024:.1f} MB and "
                    f"exceeds the Discord upload limit. It has been saved "
                    f"on the host as {COMBO_DIR / COMBO_NAME}.")
            e.description = ("This paste exceeds the Discord upload limit "
                             "and could not be attached.")
    else:
        e.description = ("The paste content could not be retrieved. "
                         "It may no longer be available.")

    if footer:
        e.set_footer(text=" | ".join(footer) + f" | {FOOTER}")
    else:
        e.set_footer(text=FOOTER)

    await channel.send(embed=e, file=file, view=view)
    if note:
        try:
            await channel.send(note)
        except Exception:
            pass
    if content:
        try:
            db.mark_sent(paste["url"], paste.get("title", ""),
                         src["id"] if src else None)
        except Exception:
            pass


class Pastes(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        try:
            await scraper.ensure()
        except Exception as ex:
            log.error("Browser unavailable: %s", ex)
        if not db.get_links() and DEFAULT_LINK:
            db.add_link(DEFAULT_LINK, "Main")
        if DEFAULT_CHANNEL and not db.get_setting("channel_id"):
            db.set_setting("channel_id", DEFAULT_CHANNEL)
        if DEFAULT_PATTERN and not db.get_setting("paste_pattern"):
            db.set_setting("paste_pattern", DEFAULT_PATTERN)
        interval = max(1, int(db.get_setting("interval", "45")))
        self.auto_check.change_interval(minutes=interval)
        self.auto_check.start()
        log.info("Paste auto-check running every %s min, %s pastes on record",
                 interval, db.sent_count())

    async def cog_unload(self):
        if self.auto_check.is_running():
            self.auto_check.stop()
        await scraper.stop()

    async def get_output_channel(self):
        cid = db.get_setting("channel_id")
        if not cid:
            return None
        try:
            ch = self.bot.get_channel(int(cid))
            return ch if ch else await self.bot.fetch_channel(int(cid))
        except Exception:
            return None

    @tasks.loop(minutes=45)
    async def auto_check(self):
        channel = await self.get_output_channel()
        if channel is None:
            return
        try:
            pastes = await check_for_new_pastes()
        except Exception as ex:
            log.error("Auto-check failed: %s", ex)
            return
        await deliver_new_pastes(pastes, channel)

    @auto_check.before_loop
    async def _wait_ready(self):
        await self.bot.wait_until_ready()

    # ---- everyone ----

    async def _cmd_latest(self, ctx, link_id):
        if link_id is not None:
            row = db.get_link(link_id)
            if row is None:
                return await ctx.reply(
                    f"No monitored link with id #{link_id}. See {PREFIX}links.",
                    mention_author=False)
            rows = [row]
        else:
            rows = db.get_links()
        if not rows:
            return await ctx.reply("No monitored links are configured.",
                                   mention_author=False)
        async with ctx.typing():
            for link in rows:
                try:
                    top = await fetch_latest(link)
                except Exception as ex:
                    await ctx.send(f"Link #{link['id']} could not be scraped: "
                                   f"{ex}")
                    continue
                if not top:
                    await ctx.send(f"No paste links were detected on link "
                                   f"#{link['id']}. An administrator can run "
                                   f"{PREFIX}inspect to diagnose.")
                    continue
                await send_paste(ctx.channel, {**top, "link": link},
                                 header="Latest paste")

    @commands.command(name="latest")
    @commands.cooldown(1, 30.0, commands.BucketType.user)
    async def latest(self, ctx, link_id: int = None):
        await self._cmd_latest(ctx, link_id)

    @commands.command(name="download")
    @commands.cooldown(1, 30.0, commands.BucketType.user)
    async def download(self, ctx, link_id: int = None):
        await self._cmd_latest(ctx, link_id)

    @commands.command(name="search")
    @commands.cooldown(1, 30.0, commands.BucketType.user)
    async def search(self, ctx, *, query: str):
        parts = query.split(maxsplit=1)
        if len(parts) == 2 and parts[0].isdigit():
            link_id, query = int(parts[0]), parts[1]
        else:
            link_id = None
        if not query.strip():
            return await ctx.reply(f"Usage: {PREFIX}search <words>",
                                   mention_author=False)
        if link_id is not None:
            row = db.get_link(link_id)
            if row is None:
                return await ctx.reply(f"No monitored link with id #{link_id}.",
                                       mention_author=False)
            rows = [row]
        else:
            rows = db.get_links()
        if not rows:
            return await ctx.reply("No monitored links are configured.",
                                   mention_author=False)
        results = []
        async with ctx.typing():
            async with scraper.lock:
                for link in rows:
                    page = None
                    try:
                        page = await scraper.new_page()
                        await _goto_and_settle(page, link["url"])
                        for p in await collect_paste_links(page, link["url"]):
                            if query.lower() in p["title"].lower():
                                results.append((link, p))
                    except Exception as ex:
                        log.error("Search failed on link #%s: %s",
                                  link["id"], ex)
                    finally:
                        if page:
                            try: await page.close()
                            except Exception: pass
        if not results:
            return await ctx.reply(f"No paste titles matching '{query}' were "
                                   f"found.", mention_author=False)
        e = Theme.embed(title=f"Search results for '{query}'",
                        description=f"{len(results)} match(es) found.",
                        color=Theme.TWILIGHT)
        for link, p in results[:15]:
            parts2 = [f"Source: link #{link['id']}"]
            if p.get("views"):
                parts2.insert(0, f"Views: {p['views']}")
            e.add_field(name=p["title"][:200], value=" | ".join(parts2),
                        inline=False)
        if len(results) > 15:
            e.set_footer(text=f"Showing 15 of {len(results)} results | {FOOTER}")
        await ctx.reply(embed=e, mention_author=False)

    @commands.command(name="paste")
    @commands.cooldown(1, 30.0, commands.BucketType.user)
    async def paste(self, ctx, url: str):
        if not url.startswith("http"):
            return await ctx.reply("Please provide a complete URL, starting "
                                   "with http or https.", mention_author=False)
        async with ctx.typing():
            page = await scraper.new_page()
            try:
                content = await extract_paste_content(page, {"url": url})
            finally:
                try: await page.close()
                except Exception: pass
        await send_paste(ctx.channel,
                         {"title": url.rstrip("/").split("/")[-1] or "Paste",
                          "url": url, "content": content},
                         header="Requested paste")

    @commands.command(name="links")
    async def links(self, ctx):
        rows = db.get_links()
        if not rows:
            return await ctx.reply("No monitored links are configured.",
                                   mention_author=False)
        e = Theme.embed(title="Monitored Profiles", color=Theme.MIDNIGHT)
        for r in rows:
            checked = (r["last_check"] or "never")[:19].replace("T", " ")
            e.add_field(name=f"#{r['id']} — {r['label'] or 'Unnamed'}",
                        value=f"Last checked: {checked}", inline=False)
        e.set_footer(text=f"The owner can add or remove monitored links. | {FOOTER}")
        await ctx.reply(embed=e, mention_author=False)

    # ---- admin ----

    @commands.command(name="history")
    @admin_only()
    async def history(self, ctx, count: int = 10):
        count = max(1, min(50, count))
        rows = db.sent_history(count)
        if not rows:
            return await ctx.reply("No pastes have been delivered yet.",
                                   mention_author=False)
        pages = []
        for i in range(0, len(rows), 5):
            chunk = rows[i:i + 5]
            e = Theme.embed(title="Delivery History",
                            description=f"Total delivered: {db.sent_count()}",
                            color=Theme.MIDNIGHT)
            for r in chunk:
                when = (r["sent_at"] or "")[:19].replace("T", " ")
                e.add_field(name=(r["title"] or "Untitled")[:80],
                            value=f"Delivered: {when} | "
                                  f"Source: link #{r['link_id']}",
                            inline=False)
            e.set_footer(text=f"Page {len(pages) + 1} | {FOOTER}")
            pages.append(e)
        await paginate(ctx, pages)

    @commands.command(name="inspect")
    @admin_only()
    async def inspect(self, ctx, link_id: int = None):
        if link_id is not None:
            row = db.get_link(link_id)
            if row is None:
                return await ctx.reply(f"No monitored link with id #{link_id}.",
                                       mention_author=False)
            rows = [row]
        else:
            rows = db.get_links()
        if not rows:
            return await ctx.reply("No monitored links are configured.",
                                   mention_author=False)
        async with ctx.typing():
            page = await scraper.new_page()
            try:
                for link in rows:
                    try:
                        await _goto_and_settle(page, link["url"])
                        pastes = await collect_paste_links(page, link["url"])
                    except Exception as ex:
                        await ctx.send(f"Link #{link['id']}: {ex}")
                        continue
                    pat = db.get_setting("paste_pattern") or "(none)"
                    kws = ", ".join(db.list_keywords()) or "(none)"
                    off = _get_offset()
                    lines = [f"LINK #{link['id']} — {link['url']}",
                             f"pattern: {pat} | keywords: {kws} | offset: {off}",
                             f"paste links found: {len(pastes)}",
                             f"selection: "
                             f"{pastes[0]['url'] if pastes else 'NOTHING'}",
                             ""]
                    for i, p in enumerate(pastes[:25]):
                        mark = "   <== selected" if i == 0 else ""
                        dup = ("   [already sent]" if db.was_sent(p["url"])
                               else "")
                        lines.append(f"[{i}] {p['title'][:50]} | "
                                     f"{p['url'][:90]}{mark}{dup}")
                    lines.append("")
                    lines.append("If the selection is wrong, use "
                                 "!setoffset <index> or !addkeyword <word>.")
                    text = "\n".join(lines)
                    if len(text) > 1900:
                        text = text[:1900] + "\n...(truncated)"
                    await ctx.send(f"```{text}```")
            finally:
                try: await page.close()
                except Exception: pass

    @commands.command(name="dumphtml")
    @admin_only()
    async def dumphtml(self, ctx, link_id: int = None):
        if link_id is not None:
            row = db.get_link(link_id)
            if row is None:
                return await ctx.reply(f"No monitored link with id #{link_id}.",
                                       mention_author=False)
            link = row
        else:
            rows = db.get_links()
            if not rows:
                return await ctx.reply("No monitored links are configured.",
                                       mention_author=False)
            link = rows[0]
        async with ctx.typing():
            page = await scraper.new_page()
            try:
                await _goto_and_settle(page, link["url"])
                html_text = await page.content()
            finally:
                try: await page.close()
                except Exception: pass
        out = Path("page_dump.html")
        out.write_text(html_text, encoding="utf-8", errors="ignore")
        if out.stat().st_size > MAX_UPLOAD:
            return await ctx.reply(
                f"The page HTML is too large to attach "
                f"({out.stat().st_size // 1024} KB). It has been saved on "
                f"the host as page_dump.html.", mention_author=False)
        await ctx.reply("The page HTML has been attached.",
                        file=discord.File(str(out)), mention_author=False)

    @commands.command(name="keywords")
    @admin_only()
    async def keywords(self, ctx):
        kws = db.list_keywords()
        if not kws:
            return await ctx.reply(
                "No keywords are configured. Every detected link title "
                f"qualifies. The owner can add keywords with {PREFIX}addkeyword.",
                mention_author=False)
        await ctx.reply("Active keywords (a link title must contain one): " +
                        ", ".join(f"{k}" for k in kws), mention_author=False)

    @commands.command(name="checknow")
    @admin_only()
    async def checknow(self, ctx):
        async with ctx.typing():
            pastes = await check_for_new_pastes()
        target = await self.get_output_channel() or ctx.channel
        if not pastes:
            return await ctx.reply("Check complete. No new pastes were found.",
                                   mention_author=False)
        sent = await deliver_new_pastes(pastes, target)
        if sent == 0:
            await ctx.reply("New pastes were found but could not be delivered. "
                            "Verify the bot's permissions in the output "
                            "channel. Delivery will be retried on the next "
                            "scheduled check.", mention_author=False)

    @commands.command(name="admins")
    @admin_only()
    async def admins(self, ctx):
        rows = db.list_admins()
        if not rows:
            return await ctx.reply("There are no administrators besides the "
                                   "owner.", mention_author=False)
        lines = []
        for r in rows:
            uid = int(r["user_id"])
            added = (r["added_at"] or "")[:19].replace("T", " ")
            lines.append(f"{display_name(ctx, uid)} — added {added}")
        await ctx.reply(embed=Theme.embed(title="Administrators",
                                           description="\n".join(lines),
                                           color=Theme.MIDNIGHT),
                        mention_author=False)

    @commands.command(name="status")
    @admin_only()
    async def status(self, ctx):
        channel = await self.get_output_channel()
        e = Theme.embed(title="Bot Status", color=Theme.MIDNIGHT)
        e.add_field(name="Monitored links", value=str(len(db.get_links())))
        e.add_field(name="Output channel",
                    value=channel.mention if channel else "not set")
        e.add_field(name="Pastes delivered", value=str(db.sent_count()))
        e.add_field(name="URL pattern",
                    value=db.get_setting("paste_pattern") or "none")
        e.add_field(name="Keywords",
                    value=", ".join(db.list_keywords()) or "none")
        e.add_field(name="Link offset", value=str(_get_offset()))
        e.add_field(name="Check interval",
                    value=f"{db.get_setting('interval', '45')} minutes "
                          f"({'running' if self.auto_check.is_running() else 'paused'})")
        await ctx.reply(embed=e, mention_author=False)

    @commands.command(name="restartbrowser")
    @admin_only()
    async def restartbrowser(self, ctx):
        async with ctx.typing():
            await scraper.restart()
        await ctx.reply("The browser has been restarted.",
                        mention_author=False)

    # ---- owner ----

    @commands.command(name="addkeyword")
    @owner_only()
    async def addkeyword(self, ctx, *, word: str):
        w = word.strip()
        if not w:
            return await ctx.reply(f"Usage: {PREFIX}addkeyword <word>",
                                   mention_author=False)
        db.add_keyword(w)
        await ctx.reply(f"Keyword '{w}' added. Only links whose titles contain "
                        f"it will be treated as pastes. Run {PREFIX}inspect "
                        f"to verify the selection.", mention_author=False)

    @commands.command(name="removekeyword")
    @owner_only()
    async def removekeyword(self, ctx, *, word: str):
        if db.remove_keyword(word.strip()):
            await ctx.reply(f"Keyword '{word}' removed.", mention_author=False)
        else:
            await ctx.reply("That keyword is not configured.",
                            mention_author=False)

    @commands.command(name="setoffset")
    @owner_only()
    async def setoffset(self, ctx, count: int = 0):
        if not 0 <= count <= 50:
            return await ctx.reply("Please choose a number between 0 and 50.",
                                   mention_author=False)
        if count == 0:
            db.del_setting("paste_offset")
            return await ctx.reply("Offset cleared. The first detected link "
                                   "will be used.", mention_author=False)
        db.set_setting("paste_offset", count)
        await ctx.reply(f"Offset set to {count}. The link previously shown as "
                        f"[{count}] will now be selected as the newest. Run "
                        f"{PREFIX}inspect to verify.", mention_author=False)

    @commands.command(name="setpattern")
    @owner_only()
    async def setpattern(self, ctx, *, pattern: str = ""):
        p = pattern.strip()
        if not p or p.lower() in ("off", "none", "clear", "reset"):
            db.del_setting("paste_pattern")
            return await ctx.reply("URL pattern cleared. All same-site "
                                   "content links will be treated as pastes.",
                                   mention_author=False)
        db.set_setting("paste_pattern", p)
        await ctx.reply(f"URL pattern set to '{p}'. Only links matching it "
                        f"will be treated as pastes. Run {PREFIX}inspect to "
                        f"verify.", mention_author=False)

    @commands.command(name="addadmin")
    @owner_only()
    async def addadmin(self, ctx, *, user: str):
        uid = await self._resolve_user(ctx, user)
        if uid is None:
            return await ctx.reply("That user could not be found. Mention "
                                   "them or use their ID.",
                                   mention_author=False)
        if uid == OWNER_ID:
            return await ctx.reply("The owner already has full access.",
                                   mention_author=False)
        db.add_admin(uid, ctx.author.id)
        await ctx.reply(f"{display_name(ctx, uid)} has been granted "
                        f"administrator access.", mention_author=False)

    @commands.command(name="removeadmin")
    @owner_only()
    async def removeadmin(self, ctx, *, user: str):
        uid = await self._resolve_user(ctx, user)
        if uid is None:
            return await ctx.reply("That user could not be found.",
                                   mention_author=False)
        if db.remove_admin(uid):
            await ctx.reply("Administrator access has been removed from "
                            f"{display_name(ctx, uid)}.",
                            mention_author=False)
        else:
            await ctx.reply("That user is not an administrator.",
                            mention_author=False)

    @staticmethod
    async def _resolve_user(ctx, arg: str):
        arg = arg.strip()
        m = re.match(r"^<@!?(\d+)>$", arg)
        if m:
            return int(m.group(1))
        if re.fullmatch(r"\d{15,20}", arg):
            return int(arg)
        try:
            return (await commands.MemberConverter().convert(ctx, arg)).id
        except Exception:
            return None

    @commands.command(name="addlink")
    @owner_only()
    async def addlink(self, ctx, url: str, *, label: str = ""):
        if not url.startswith("http"):
            return await ctx.reply("Please provide a complete URL, starting "
                                   "with http or https.", mention_author=False)
        if not db.add_link(url, label):
            return await ctx.reply("That link is already monitored.",
                                   mention_author=False)
        row = db.get_link_by_url(url)
        msg = await ctx.reply(f"Link #{row['id']} added. Fetching the current "
                              f"latest paste...", mention_author=False)
        try:
            top = await fetch_latest(row)
        except Exception as ex:
            return await msg.edit(content=f"Link #{row['id']} added, but it "
                                          f"could not be scraped: {ex}")
        if not top:
            await msg.edit(content=f"Link #{row['id']} added, but no pastes "
                                   f"were detected. Run {PREFIX}inspect "
                                   f"{row['id']} to diagnose.")
            return
        db.set_last(row["id"], top["url"])
        target = await self.get_output_channel()
        if target:
            await send_paste(target, {**top, "link": row},
                             header="Now monitoring — current latest")
            await msg.edit(content=f"Link #{row['id']} added and delivered to "
                                   f"{target.mention}. Only new pastes will "
                                   f"be delivered from now on.")
        else:
            await ctx.send(f"Current latest paste: {top['title']}\n"
                           f"No output channel is set. Use {PREFIX}setchannel "
                           f"to configure one.")

    @commands.command(name="removelink")
    @owner_only()
    async def removelink(self, ctx, link_id: int):
        row = db.get_link(link_id)
        if row is None:
            return await ctx.reply(f"No monitored link with id #{link_id}.",
                                   mention_author=False)
        view = ConfirmView(ctx.author.id)
        msg = await ctx.reply(f"Remove monitored link #{link_id} "
                              f"({row['label'] or 'Unnamed'})? This cannot "
                              f"be undone automatically.",
                              view=view, mention_author=False)
        await view.wait()
        if view.value:
            db.remove_link(link_id)
            await msg.edit(content=f"Link #{link_id} removed.", view=None)
        else:
            await msg.edit(content="Action cancelled or timed out.",
                           view=None)

    @commands.command(name="setchannel")
    @owner_only()
    async def setchannel(self, ctx, channel: discord.TextChannel):
        db.set_setting("channel_id", channel.id)
        await ctx.reply(f"Output channel set to {channel.mention}. New pastes "
                        f"will be delivered there.", mention_author=False)

    @commands.command(name="setinterval")
    @owner_only()
    async def setinterval(self, ctx, minutes: int):
        if not 5 <= minutes <= 1440:
            return await ctx.reply("Please choose a value between 5 and 1440 "
                                   "minutes.", mention_author=False)
        db.set_setting("interval", minutes)
        self.auto_check.change_interval(minutes=minutes)
        await ctx.reply(f"Check interval set to {minutes} minutes.",
                        mention_author=False)

    @commands.command(name="pause")
    @owner_only()
    async def pause(self, ctx):
        if self.auto_check.is_running():
            self.auto_check.stop()
            await ctx.reply("Automatic checking paused.", mention_author=False)
        else:
            await ctx.reply("Automatic checking is already paused.",
                            mention_author=False)

    @commands.command(name="resume")
    @owner_only()
    async def resume(self, ctx):
        if not self.auto_check.is_running():
            self.auto_check.start()
            await ctx.reply("Automatic checking resumed.",
                            mention_author=False)
        else:
            await ctx.reply("Automatic checking is already running.",
                            mention_author=False)


async def setup(bot):
    await bot.add_cog(Pastes(bot))